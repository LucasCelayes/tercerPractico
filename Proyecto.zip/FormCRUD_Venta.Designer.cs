﻿namespace SistemaGestionUI.FormVenta
{
    partial class FormCRUD_Venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnGuardar = new Button();
            btnEliminar = new Button();
            btnVolver = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtIdVenta = new TextBox();
            txtComentarios = new TextBox();
            txtIdVendedor = new TextBox();
            SuspendLayout();
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(1241, 435);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(112, 34);
            btnGuardar.TabIndex = 0;
            btnGuardar.Text = "Guardar";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Location = new Point(717, 435);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(112, 34);
            btnEliminar.TabIndex = 1;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnVolver
            // 
            btnVolver.Location = new Point(210, 439);
            btnVolver.Name = "btnVolver";
            btnVolver.Size = new Size(112, 34);
            btnVolver.TabIndex = 2;
            btnVolver.Text = "Volver";
            btnVolver.UseVisualStyleBackColor = true;
            btnVolver.Click += btnVolver_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(238, 95);
            label1.Name = "label1";
            label1.Size = new Size(79, 25);
            label1.TabIndex = 3;
            label1.Text = "ID Venta";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(238, 163);
            label2.Name = "label2";
            label2.Size = new Size(113, 25);
            label2.TabIndex = 4;
            label2.Text = "Comentarios";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(238, 234);
            label3.Name = "label3";
            label3.Size = new Size(112, 25);
            label3.TabIndex = 5;
            label3.Text = "ID Vendedor";
            // 
            // txtIdVenta
            // 
            txtIdVenta.Location = new Point(563, 89);
            txtIdVenta.Name = "txtIdVenta";
            txtIdVenta.ReadOnly = true;
            txtIdVenta.Size = new Size(358, 31);
            txtIdVenta.TabIndex = 6;
            // 
            // txtComentarios
            // 
            txtComentarios.Location = new Point(563, 176);
            txtComentarios.Name = "txtComentarios";
            txtComentarios.Size = new Size(358, 31);
            txtComentarios.TabIndex = 7;
            // 
            // txtIdVendedor
            // 
            txtIdVendedor.Location = new Point(563, 234);
            txtIdVendedor.Name = "txtIdVendedor";
            txtIdVendedor.Size = new Size(358, 31);
            txtIdVendedor.TabIndex = 8;
            // 
            // FormCRUD_Venta
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1422, 509);
            Controls.Add(txtIdVendedor);
            Controls.Add(txtComentarios);
            Controls.Add(txtIdVenta);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnVolver);
            Controls.Add(btnEliminar);
            Controls.Add(btnGuardar);
            Name = "FormCRUD_Venta";
            Text = "FormCRUD_Venta";
            Load += FormCRUD_Venta_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnGuardar;
        private Button btnEliminar;
        private Button btnVolver;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtIdVenta;
        private TextBox txtComentarios;
        private TextBox txtIdVendedor;
    }
}