﻿namespace SistemaGestionUI
{
    public class Class1
    {

    }
}
