﻿namespace SistemaGestionUI.FormProductoVendido
{
    partial class FormCRUD_SellProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            txtIdSellProduct = new TextBox();
            txtStock = new TextBox();
            txtProductId = new TextBox();
            txtIdVenta = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(357, 435);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 0;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(724, 435);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 1;
            button2.Text = "Eliminar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(1072, 435);
            button3.Name = "button3";
            button3.Size = new Size(112, 34);
            button3.TabIndex = 2;
            button3.Text = "Guardar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(137, 45);
            label1.Name = "label1";
            label1.Size = new Size(172, 25);
            label1.TabIndex = 3;
            label1.Text = "Productos Vendidos";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(216, 101);
            label2.Name = "label2";
            label2.Size = new Size(180, 25);
            label2.TabIndex = 4;
            label2.Text = "ID producto Vendido";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(216, 164);
            label3.Name = "label3";
            label3.Size = new Size(55, 25);
            label3.TabIndex = 5;
            label3.Text = "Stock";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(216, 224);
            label4.Name = "label4";
            label4.Size = new Size(108, 25);
            label4.TabIndex = 6;
            label4.Text = "ID Producto";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(216, 290);
            label5.Name = "label5";
            label5.Size = new Size(78, 25);
            label5.TabIndex = 7;
            label5.Text = "ID venta";
            // 
            // txtIdSellProduct
            // 
            txtIdSellProduct.Location = new Point(660, 117);
            txtIdSellProduct.Name = "txtIdSellProduct";
            txtIdSellProduct.Size = new Size(150, 31);
            txtIdSellProduct.TabIndex = 8;
            // 
            // txtStock
            // 
            txtStock.Location = new Point(660, 164);
            txtStock.Name = "txtStock";
            txtStock.Size = new Size(150, 31);
            txtStock.TabIndex = 9;
            // 
            // txtProductId
            // 
            txtProductId.Location = new Point(660, 218);
            txtProductId.Name = "txtProductId";
            txtProductId.Size = new Size(150, 31);
            txtProductId.TabIndex = 10;
            // 
            // txtIdVenta
            // 
            txtIdVenta.Location = new Point(660, 284);
            txtIdVenta.Name = "txtIdVenta";
            txtIdVenta.Size = new Size(150, 31);
            txtIdVenta.TabIndex = 12;
            // 
            // FormCRUD_SellProduct
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1478, 507);
            Controls.Add(txtIdVenta);
            Controls.Add(txtProductId);
            Controls.Add(txtStock);
            Controls.Add(txtIdSellProduct);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "FormCRUD_SellProduct";
            Text = "FormCRUD_SellProduct";
            Load += FormCRUD_SellProduct_Load_1;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button2;
        private Button button3;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private TextBox txtIdSellProduct;
        private TextBox txtStock;
        private TextBox txtProductId;
        private TextBox txtIdVenta;
    }
}