﻿using SistemaGestionData;
using SistemaGestionEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionBussiness
{
    public class VentaBussiness
    {
        public static Venta GetVentaById(int id)
        {
            return VentaData.GetVentaById(id);
        }
        public static List<Venta> GetVenta()

        {
            return VentaData.ListaVentas();
        }

        public static void EliminarVenta(int id)
        {
            VentaData.DeleteVenta(id);
        }

        public static void ModificarVenta(Venta venta)
        {
            VentaData.UpdateVenta(venta.Id, venta);
        }

        public static void AltaVenta(Venta venta)
        {
            VentaData.CreateVenta(venta);
        }
    }
}

