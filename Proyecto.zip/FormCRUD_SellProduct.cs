﻿
using SistemaGestionUI.FormProductoVendido;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaGestionEntities;
using SistemaGestionData;


namespace SistemaGestionUI.FormProductoVendido
{
    public partial class FormCRUD_SellProduct : Form
    {
        public FormCRUD_SellProduct()
        {
            InitializeComponent();
        }
        public void Clean()
        {
            txtIdSellProduct.Text = "";

            txtStock.Text = "";

            txtProductId.Text = "";

            txtIdVenta.Text = "";

        }

        private void FormCRUD_SellProduct_Load(object sender, EventArgs e)
        {
            int idSellProduct = FormInit.formSellProduct.sellProductId;
            if (idSellProduct > 0)
            {
                ProductoVendido _txtSell = ProductoVendidoData.GetUserById(idSellProduct);

                
                txtStock.Text = _txtSell.Stock.ToString();
                txtProductId.Text = _txtSell.IdProducto.ToString();
                txtIdVenta.Text = _txtSell.IdVenta.ToString();
                txtIdSellProduct.Text = idSellProduct.ToString();
            }
            else
            {
                Clean();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormInit.formSellProduct.sellProductId = 0;
            FormInit.formSellProduct.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int stock = Convert.ToInt32(txtStock.Text);
            int productId = Convert.ToInt32(txtProductId.Text);
            int sellId = Convert.ToInt32(txtIdVenta.Text);

            int sellProductId = FormInit.formSellProduct.sellProductId;

            ProductoVendido newSellProduct = new ProductoVendido(stock, productId, sellId);

            if (sellProductId > 0)
            {
                ProductoVendidoData.UpdateProductoVendido(productId, newSellProduct);
                MessageBox.Show("Se modifico el producto vendido");
            }
            else
            {
                ProductoVendidoData.CreateProductoVendido(newSellProduct);
                MessageBox.Show("Se creo un nuevo producto vendido");
            }
            Clean();
            this.Close();
            FormInit.formSellProduct.sellProductId = 0;
            FormInit.formSellProduct.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string id = txtProductId.Text;
            ProductoVendidoData.DeleteProductoVendido(int.Parse(id));
            MessageBox.Show("Se borro el Producto Vendido");
            Clean();
            FormInit.formSellProduct.sellProductId = 0;
            this.Close();
            FormInit.formSellProduct.Show();
        }

        private void FormCRUD_SellProduct_Load_1(object sender, EventArgs e)
        {

        }
    }
}

