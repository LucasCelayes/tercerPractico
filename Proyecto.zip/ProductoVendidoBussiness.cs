﻿using SistemaGestionData;
using SistemaGestionEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionBussiness
{
    public class ProductoVendidoBussiness
    {

        public static void AltaProductoVendido(ProductoVendido productoVendido)
        {
            ProductoVendidoData.CreateProductoVendido(productoVendido);
        }

        public static void EliminarProductoVendido(int id)
        {
            ProductoVendidoData.DeleteProductoVendido(id);
        }

        public static ProductoVendido GetProductoVendidoById(int id)
        {
            return ProductoVendidoData.GetProductoVendidoById(id);
        }

        public static List<ProductoVendido> GetProductoVendido()

        {
            return ProductoVendidoData.ListaProductoVendidos();
        }



        public static void ModificarProductoVendido(ProductoVendido productoVendido)
        {
            ProductoVendidoData.UpdateProductoVendido(productoVendido.Id, productoVendido);
        }

     
    }
}