﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaGestionEntities;
using SistemaGestionData;


namespace SistemaGestionUI.FormProducto
{
    public partial class FormCRUD_Product : Form
    {
        public FormCRUD_Product()
        {
            InitializeComponent();
        }

        private void FormCRUD_Product_Load(object sender, EventArgs e)
        {
            int idProduct = FormInit.formProduct.productId;

            if (idProduct > 0)
            {


                Producto _txtProduct = ProductoData.GetUserById(idProduct);


                txtDescription.Text = _txtProduct.Descripciones;
                txtCost.Text = _txtProduct.Costo.ToString();
                txtSellPrice.Text = _txtProduct.PrecioVenta.ToString();
                txtStock.Text = _txtProduct.Stock.ToString();
                txtUserId.Text = _txtProduct.IdUsuario.ToString();
                txtProductId.Text = idProduct.ToString();

            }
            else
            {
                Clean();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            FormInit.formProduct.productId = 0;
            FormInit.formProduct.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string description = txtDescription.Text;
            int cost = Convert.ToInt32(txtCost.Text);
            int sellPrice = Convert.ToInt32(txtSellPrice.Text);
            double stock = Convert.ToInt32(txtStock.Text);
            int userId = Convert.ToInt32(txtUserId.Text);

            int productId = FormInit.formProduct.productId;

            Producto newproduct = new Producto(description, cost, sellPrice, stock, userId);

            if (productId > 0)
            {
                ProductoData.UpdateProduct(productId, newproduct);
                MessageBox.Show("Se actualizo el producto");
            }
            else
            {
                ProductoData.CreateProduct(newproduct);
                MessageBox.Show("Se creo el producto");
            }
            Clean();
            this.Close();
            FormInit.formProduct.productId = 0;
            FormInit.formProduct.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string id = txtProductId.Text;
            ProductoData.DeleteProduct(int.Parse(id));
            MessageBox.Show("Se borro el Producto");
            Clean();
            FormInit.formProduct.productId = 0;
            this.Close();
            FormInit.formProduct.Show();
        }
        public void Clean()
        {
            txtDescription.Text = "";
            txtCost.Text = "";
            txtSellPrice.Text = "";
            txtStock.Text = "";
            txtUserId.Text = "";

        }
    }
}

   

