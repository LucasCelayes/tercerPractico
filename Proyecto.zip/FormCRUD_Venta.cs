﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaGestionData;
using SistemaGestionEntities;

namespace SistemaGestionUI.FormVenta
{
    public partial class FormCRUD_Venta : Form
    {

        public FormCRUD_Venta()
        {
            InitializeComponent();
        }

        private void FormCRUD_Venta_Load(object sender, EventArgs e)
        {
            int idVenta = FormInit.formSell.ventaId;
            if (idVenta > 0)
            {
                Venta _txtVenta = VentaData.GetVentaById(idVenta);
                txtIdVenta.Text = idVenta.ToString();
                txtComentarios.Text = _txtVenta.Comentarios;
                txtIdVendedor.Text = _txtVenta.IdUsuario.ToString();

            }
            else
            {
                Limpiar();
            }
        }
        private void Limpiar()
        {
            txtIdVenta.Text = "";
            txtComentarios.Text = "";
            txtIdVendedor.Text = "";
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            string id = txtIdVenta.Text;
            VentaData.DeleteVenta(int.Parse(id));
            MessageBox.Show("Se borro la Venta");
            Limpiar();
            FormInit.formSell.ventaId = 0;
            this.Close();
            FormInit.formSell.Show();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            string commentary = txtComentarios.Text.ToString();
            int userID = Convert.ToInt32(txtIdVendedor.Text);


            int sellId = FormInit.formSell.ventaId;

            Venta newSell = new Venta(commentary, userID);

            if (sellId > 0)
            {
                VentaData.UpdateVenta(sellId, newSell);
                MessageBox.Show("Se modifico la venta");
            }
            else
            {
                VentaData.CreateVenta(newSell);
                MessageBox.Show("Se creo una nueva venta");
            }
            Limpiar();
            this.Close();
            FormInit.formSell.ventaId = 0;
            FormInit.formSell.Show();

        }

        private void btnVolver_Click(object sender, EventArgs e)
        
            {
                this.Close();
            FormInit.formSell.ventaId = 0;
                FormInit.formSell.Show();
            }
        
    }
}
