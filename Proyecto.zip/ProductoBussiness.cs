﻿using SistemaGestionData;
using SistemaGestionEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionBussiness
{
    public class ProductoBussiness
    {

        public static void AltaProducto(Producto producto)
        {
            ProductoData.CreateProduct(producto);
        }

        public static void EliminarProducto(int id)
        {
            ProductoData.DeleteProduct(id);
        }

        public static Producto GetProductoById(int id)
        {
            return ProductoData.GetProductoById(id);
        }

        public static List<Producto> GetProducto()

        {
            return ProductoData.ListaProductos();
        }



        public static void ModificarProducto(Producto producto)
        {
            ProductoData.UpdateProduct(producto.Id, producto);
        }
    }
}
