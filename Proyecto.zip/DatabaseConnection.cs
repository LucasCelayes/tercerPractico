﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaGestionData
{
    public static class DatabaseConnection
    {
        private static readonly string connectionString = @"LAPTOP-R065LQAN\SQLEXPRESS02;Database=SistemaLogistica;Trusted_Connection=True;";
    
        public static SqlConnection GetConnection() {
            return new SqlConnection(connectionString); 
        }
    }
}
