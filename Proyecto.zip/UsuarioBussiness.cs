﻿using SistemaGestionData;
using SistemaGestionEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SistemaGestionBussiness
{
    public class UsuarioBussiness
    {
      
        public static void AltaUsuario(Usuario usuario)
        {
            UsuarioData.CreateUser(usuario);
        }

        public static void EliminarUsuario(int id)
        {
            UsuarioData.DeleteUser(id);
        }

        public static Usuario GetUserById(int id)
        {
            return UsuarioData.GetUserById(id);
        }

        public static List<Usuario> GetUsuarios()

        {
            return UsuarioData.ListaUsuarios();
        }

       

        public static void ModificarUsuario( Usuario usuario)
        {
            UsuarioData.UpdateUser(usuario.Id,usuario);
        }
    }
    }
