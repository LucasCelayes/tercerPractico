﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaGestionData;
using SistemaGestionEntities;


namespace SistemaGestionUI.FormProductoVendido
{
    public partial class FormSellProduct : Form

    {
        public int sellProductId;
        public FormSellProduct()
        {
            InitializeComponent();
        }

        private void dgvFormSellProduct_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                int rowSelected = (int)e.RowIndex;
                sellProductId = int.Parse(dgvFormSellProduct[0, rowSelected].Value.ToString());
            }
            FormCRUD_SellProduct formCrud_SellProduct = new FormCRUD_SellProduct();
            FormInit.formSellProduct.Hide();
            formCrud_SellProduct.Show();
        }
        private void LoadSellProducts()
        {
            List<ProductoVendido> sellProducts = ProductoVendidoData.ListaProductoVendidos();
            dgvFormSellProduct.AutoGenerateColumns = true;
            dgvFormSellProduct.DataSource = sellProducts;
        }
        private void FormSellProduct_Load(object sender, EventArgs e)
        {
            LoadSellProducts();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCRUD_SellProduct formCrud = new FormCRUD_SellProduct();
            FormInit.formSellProduct.Hide();
            formCrud.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dgvFormSellProduct.DataSource = null;
            dgvFormSellProduct.Refresh();
            LoadSellProducts();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormCRUD_SellProduct formCrud = new FormCRUD_SellProduct();
            FormInit.formSellProduct.Hide();
            formCrud.Show();
        }
    }
}
