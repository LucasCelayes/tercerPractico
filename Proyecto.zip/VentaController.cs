﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SistemaGestionBussiness;
using SistemaGestionEntities;

namespace WebApplication2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VentaController : ControllerBase
    {
        [HttpGet(Name = "GetVenta")]
        public IEnumerable<Venta> venta()
        {
            return VentaBussiness.GetVenta().ToArray();   
        }
        [HttpGet("{id}")]
        public IActionResult GetVentaById(int id)
        {
            Venta venta = VentaBussiness.GetVentaById( id);
            if (venta == null)
            {
                return NotFound();
            }
            return Ok(venta);
        }
        [HttpDelete(Name = "EliminarVenta")]
        public void Delete([FromBody] int id)
        {
            VentaBussiness.EliminarVenta(id);
        }
        [HttpPut(Name = "ModificarVenta")]
        public void Put([FromBody] Venta venta)
        {
            VentaBussiness.ModificarVenta(venta);
        }
        [HttpPost(Name = "AltaVenta")]
        public void Post([FromBody] Venta venta)
        {
            VentaBussiness.AltaVenta(venta);
        }


    }
}


    