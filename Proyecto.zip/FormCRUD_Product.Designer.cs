﻿namespace SistemaGestionUI.FormProducto
{
    partial class FormCRUD_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            txtProductId = new TextBox();
            txtDescription = new TextBox();
            txtCost = new TextBox();
            txtSellPrice = new TextBox();
            txtStock = new TextBox();
            txtUserId = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(144, 31);
            label1.Name = "label1";
            label1.Size = new Size(93, 25);
            label1.TabIndex = 0;
            label1.Text = "Productos";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(273, 122);
            label2.Name = "label2";
            label2.Size = new Size(108, 25);
            label2.TabIndex = 1;
            label2.Text = "ID Producto";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(273, 171);
            label3.Name = "label3";
            label3.Size = new Size(104, 25);
            label3.TabIndex = 2;
            label3.Text = "Descripcion";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(273, 227);
            label4.Name = "label4";
            label4.Size = new Size(59, 25);
            label4.TabIndex = 3;
            label4.Text = "Costo";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(273, 275);
            label5.Name = "label5";
            label5.Size = new Size(136, 25);
            label5.TabIndex = 4;
            label5.Text = "Precio De Venta";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(277, 333);
            label6.Name = "label6";
            label6.Size = new Size(55, 25);
            label6.TabIndex = 5;
            label6.Text = "Stock";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(271, 390);
            label7.Name = "label7";
            label7.Size = new Size(110, 25);
            label7.TabIndex = 6;
            label7.Text = "Id Vendedor";
            // 
            // button1
            // 
            button1.Location = new Point(559, 457);
            button1.Name = "button1";
            button1.Size = new Size(112, 34);
            button1.TabIndex = 7;
            button1.Text = "Volver";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(739, 458);
            button2.Name = "button2";
            button2.Size = new Size(112, 34);
            button2.TabIndex = 8;
            button2.Text = "Eliminar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Location = new Point(912, 458);
            button3.Name = "button3";
            button3.Size = new Size(112, 34);
            button3.TabIndex = 9;
            button3.Text = "Guardar";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // txtProductId
            // 
            txtProductId.Location = new Point(639, 116);
            txtProductId.Name = "txtProductId";
            txtProductId.Size = new Size(150, 31);
            txtProductId.TabIndex = 10;
            // 
            // txtDescription
            // 
            txtDescription.Location = new Point(639, 168);
            txtDescription.Name = "txtDescription";
            txtDescription.Size = new Size(150, 31);
            txtDescription.TabIndex = 11;
            // 
            // txtCost
            // 
            txtCost.Location = new Point(639, 221);
            txtCost.Name = "txtCost";
            txtCost.Size = new Size(150, 31);
            txtCost.TabIndex = 12;
            // 
            // txtSellPrice
            // 
            txtSellPrice.Location = new Point(639, 275);
            txtSellPrice.Name = "txtSellPrice";
            txtSellPrice.Size = new Size(150, 31);
            txtSellPrice.TabIndex = 13;
            // 
            // txtStock
            // 
            txtStock.Location = new Point(639, 333);
            txtStock.Name = "txtStock";
            txtStock.Size = new Size(150, 31);
            txtStock.TabIndex = 14;
            // 
            // txtUserId
            // 
            txtUserId.Location = new Point(639, 387);
            txtUserId.Name = "txtUserId";
            txtUserId.Size = new Size(150, 31);
            txtUserId.TabIndex = 15;
            // 
            // FormCRUD_Product
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1466, 504);
            Controls.Add(txtUserId);
            Controls.Add(txtStock);
            Controls.Add(txtSellPrice);
            Controls.Add(txtCost);
            Controls.Add(txtDescription);
            Controls.Add(txtProductId);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormCRUD_Product";
            Text = "FormProduct";
            Load += FormCRUD_Product_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Button button1;
        private Button button2;
        private Button button3;
        private TextBox txtProductId;
        private TextBox txtDescription;
        private TextBox txtCost;
        private TextBox txtSellPrice;
        private TextBox txtStock;
        private TextBox txtUserId;
    }
}