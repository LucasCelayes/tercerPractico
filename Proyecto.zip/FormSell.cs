﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SistemaGestionBussiness;
using SistemaGestionEntities;

namespace SistemaGestionUI.FormVenta
{
    public partial class FormSell : Form
    {
        public int ventaId;
        
        public FormSell()
        {
            InitializeComponent();
        }
        private void CargaVenta()
        {
            List<Venta> ventas = VentaBussiness.GetVenta();
            dgvVenta.AutoGenerateColumns = true;
            dgvVenta.DataSource = ventas;
        }
        private void FormVenta_Load(object sender, EventArgs e)
        {
            CargaVenta();

        }

        private void dgvVenta_CellClick(object sender, DataGridViewCellEventArgs e)
        
        {

            if (e.RowIndex >= 0)  
            {
                int rowSelected = (int)e.RowIndex;
                ventaId = int.Parse(dgvVenta[0, rowSelected].Value.ToString());
                    
            }
            FormCRUD_Venta formCrud = new FormCRUD_Venta();
            FormInit.formSell.Hide();
            formCrud.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Program.formInit.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            dgvVenta.DataSource = null;
            dgvVenta.Refresh();
            CargaVenta();
        }
       


    }
}
